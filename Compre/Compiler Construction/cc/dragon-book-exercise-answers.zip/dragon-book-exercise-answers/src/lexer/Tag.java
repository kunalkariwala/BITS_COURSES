package lexer;

public class Tag {
	public final static int
		NUM = 256,
		ID = 257,
		TRUE = 258,
		FALSE = 259,
		REL = 260;
}
